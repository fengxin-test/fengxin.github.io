
DROP DATABASE if exists ssm;
/*创建数据库示例*/
CREATE DATABASE ssm CHARACTER SET 'utf8' COLLATE 'utf8_general_ci';

use ssm;

SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for tb_msg
-- ----------------------------
DROP TABLE IF EXISTS `tb_msg`;
CREATE TABLE `tb_msg`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `content` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 22 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of tb_msg
-- ----------------------------
INSERT INTO `tb_msg` VALUES (16, '今天是星期6');
INSERT INTO `tb_msg` VALUES (17, '明天是星期天');
INSERT INTO `tb_msg` VALUES (18, '明天就回家啦！！！');
INSERT INTO `tb_msg` VALUES (19, '今天天气真好');
INSERT INTO `tb_msg` VALUES (20, '快放假啦！！');
INSERT INTO `tb_msg` VALUES (21, '今天是星期6');

-- ----------------------------
-- Table structure for tb_role
-- ----------------------------
DROP TABLE IF EXISTS `tb_role`;
CREATE TABLE `tb_role`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `rolename` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `roledesc` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 3 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of tb_role
-- ----------------------------
INSERT INTO `tb_role` VALUES (1, 'admin', 'admin');
INSERT INTO `tb_role` VALUES (2, 'user', 'user');

-- ----------------------------
-- Table structure for tb_user
-- ----------------------------
DROP TABLE IF EXISTS `tb_user`;
CREATE TABLE `tb_user`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `password` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 24 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of tb_user
-- ----------------------------
INSERT INTO `tb_user` VALUES (1, 'admin', '123');
INSERT INTO `tb_user` VALUES (2, 'zhagnsan', '123456');
INSERT INTO `tb_user` VALUES (3, 'lisi', '123456');
INSERT INTO `tb_user` VALUES (5, 'xyz', '123456');
INSERT INTO `tb_user` VALUES (6, 'smja', '123456');
INSERT INTO `tb_user` VALUES (7, '7788', '123456');
INSERT INTO `tb_user` VALUES (8, 'asdj', '123456');
INSERT INTO `tb_user` VALUES (9, 'asjs', '123456');
INSERT INTO `tb_user` VALUES (10, 'wangqing', '123456');
INSERT INTO `tb_user` VALUES (11, '孙茂珺', '123456');
INSERT INTO `tb_user` VALUES (12, '张三', '123456');

-- ----------------------------
-- Table structure for user_role
-- ----------------------------
DROP TABLE IF EXISTS `user_role`;
CREATE TABLE `user_role`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `userid` int NOT NULL,
  `roleid` int NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 10 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of user_role
-- ----------------------------
INSERT INTO `user_role` VALUES (1, 1, 1);
INSERT INTO `user_role` VALUES (3, 2, 2);
INSERT INTO `user_role` VALUES (4, 3, 2);
INSERT INTO `user_role` VALUES (5, 4, 2);
INSERT INTO `user_role` VALUES (6, 5, 2);
INSERT INTO `user_role` VALUES (7, 6, 2);
INSERT INTO `user_role` VALUES (8, 7, 2);
INSERT INTO `user_role` VALUES (9, 8, 2);

/*==============================================================*/
/* Table: operate_log                                              */
/*==============================================================*/
DROP TABLE IF EXISTS `operate_log`;
CREATE TABLE `operate_log`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '操作日志表ID',
	`user_id` bigint(20) COMMENT '用户ID',
  `operate_code` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '' COMMENT '操作代码',
  `operate_message` varchar(1000) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '' COMMENT '操作消息',
  `lock_flag` varchar(1) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT 'N' COMMENT '锁定标记',
  `activity_status` varchar(1) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT 'Y' COMMENT '是否有效',
  `created_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP(0) COMMENT '创建时间',
  `last_update_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP(0) ON UPDATE CURRENT_TIMESTAMP(0) COMMENT '最后更新时间',
  PRIMARY KEY (`id`)
);
alter table operate_log comment '操作日志';

-- 测试
insert into operate_log(user_id,operate_code, operate_message) values('1','LOGIN', '登录系统');
insert into operate_log(user_id,operate_code, operate_message) values('1','LOGOUT', '退出系统');
insert into operate_log(user_id,operate_code, operate_message) values('1','REGIST', '注册账号');
insert into operate_log(user_id,operate_code, operate_message) values('2','LOGIN', '登录系统');
insert into operate_log(user_id,operate_code, operate_message) values('2','LOGOUT', '退出系统');
select * from operate_log;

SET FOREIGN_KEY_CHECKS = 1;
