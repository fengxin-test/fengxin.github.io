package com.lean.example.controller;


import com.github.pagehelper.PageInfo;
import com.lean.example.eo.Role;
import com.lean.example.service.IRoleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpSession;


@Controller
@RequestMapping("/role")
public class RoleController {

    @Autowired
    private IRoleService roleService;

    @RequestMapping("/findAll.do")
    public ModelAndView findAll(@RequestParam(defaultValue = "1") int currentPage,String rolename,@RequestParam(defaultValue = "0")int type,HttpSession session){
        //当搜索的时候
        if(type==1){
            session.setAttribute("searchrolename",rolename);
        }else {
            rolename= (String) session.getAttribute("searchrolename");
        }

        PageInfo<Role> pageInfo=roleService.findAll(currentPage,rolename);
        ModelAndView modelAndView=new ModelAndView();
        modelAndView.addObject("pageInfo",pageInfo);
        modelAndView.addObject("searchRolename",rolename);
        modelAndView.setViewName("role-list");
        return modelAndView;
    }
}
