package com.lean.example.dao.impl;


import com.lean.example.eo.Role;
import com.lean.example.eo.UserRole;
import com.lean.example.dao.IRoleDao;
import com.lean.example.mapper.RoleMapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class RoleDao implements IRoleDao {
    @Autowired
    private RoleMapper mapper;

    public int getTotalCount(String rolename){
        return mapper.getTotalCount(rolename);
    }

    @Override
    public List<Role> findAll(String rolename){
        return mapper.findAll(rolename);
    }

    @Override
    public List<Integer> findRoleIdByUserId(int userId) {
        return mapper.findRoleIdByUserId(userId);
    }

    @Override
    public List<Role> findRoleByUserId(int id) {
        return mapper.findRoleByUserId(id);
    }

    @Override
    public void addRole(UserRole userRole) {
        mapper.addRole(userRole);
    }
}
