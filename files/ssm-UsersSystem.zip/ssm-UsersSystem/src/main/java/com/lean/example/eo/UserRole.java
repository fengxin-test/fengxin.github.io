package com.lean.example.eo;

import lombok.Data;

@Data
public class UserRole {
    private int id;
    private int userId;
    private int roleId;
}
