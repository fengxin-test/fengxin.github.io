package com.lean.example.service.impl;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.lean.example.dao.IUserDao;
import com.lean.example.eo.Role;
import com.lean.example.eo.User;
import com.lean.example.service.IUserService;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UserService implements IUserService {
    Logger logger = LogManager.getLogger(this.getClass());

    @Autowired
    private IUserDao userDao;

    @Override
    public int login(String username, String password) {
        User user = userDao.findUserByUserName(username);
        if (user!=null && user.getPassword().equals(password)){
            return user.getId();
        }
        return -1;
    }

    @Override
    public PageInfo<User> findAll(int currentPage, String username) {
        int pageNo = currentPage;
        if(pageNo<1){
            pageNo = 1;
        }
        int pageSize= 5;
        int offset = (pageNo-1)*pageSize;
        //获取分页数据
        PageHelper.startPage(pageNo, pageSize);
        List<User> userList = userDao.findAll(username);
        PageInfo<User> pageInfo=new PageInfo<User>(userList);
        logger.info("total=" + pageInfo.getTotal());
        return pageInfo;
    }

    /*@Override
    public List<User> findAll() {
        return userDao.findAll();
    }*/

    @Override
    public void deleteById(int id) {
        userDao.deleteById(id);
    }

    @Override
    public void add(User user) {
        userDao.add(user);
    }

    @Override
    public User selectUserById(int id) {
        return userDao.selectById(id);
    }

    @Override
    public void update(User user) {
        userDao.update(user);
    }

    @Override
    public void deleteAll(List<Integer> ids) {
        userDao.deleteAll(ids);
    }
}
