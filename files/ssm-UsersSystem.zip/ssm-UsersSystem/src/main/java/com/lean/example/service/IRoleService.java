package com.lean.example.service;

import com.github.pagehelper.PageInfo;
import com.lean.example.eo.Role;

import java.util.List;

public interface IRoleService {
    PageInfo<Role> findAll(int currentPage, String rolename);

    List<Integer> findRoleId(int userId);

    List<Role> findRoleByUserId(int id);


    void add(List<Integer> ids, String userId);
}
