package com.lean.example.mapper;

import com.lean.example.eo.Role;
import com.lean.example.eo.UserRole;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface RoleMapper {
    int getTotalCount(@Param("rolename")String rolename);

    List<Role> findAll(@Param("rolename") String rolename);

    List<Integer> findRoleIdByUserId(int userId);

    List<Role> findRoleByUserId(int id);


    void addRole(UserRole userRole);
}
