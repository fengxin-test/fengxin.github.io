package com.lean.example.service.impl;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.lean.example.eo.Role;
import com.lean.example.eo.User;
import com.lean.example.eo.UserRole;
import com.lean.example.dao.IRoleDao;
import com.lean.example.service.IRoleService;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class RoleService implements IRoleService {
    Logger logger = LogManager.getLogger(this.getClass());

    @Autowired
    private IRoleDao roleDao;

    @Override
    public PageInfo<Role> findAll(int currentPage, String rolename) {
        int pageNo = currentPage;
        if(pageNo<1){
            pageNo = 1;
        }
        int pageSize= 5;
        //获取分页数据
        PageHelper.startPage(pageNo,pageSize);
        List<Role> roleList = roleDao.findAll(rolename);
        PageInfo<Role> pageInfo=new PageInfo<Role>(roleList);
        logger.info("total=" + pageInfo.getTotal());
        return pageInfo;
    }

    @Override
    public List<Integer> findRoleId(int userId) {
        return roleDao.findRoleIdByUserId(userId);
    }

    @Override
    public List<Role> findRoleByUserId(int id) {
        return roleDao.findRoleByUserId(id);
    }

    @Override
    public void add(List<Integer> ids, String userId) {
        for(int roleId:ids){
            UserRole userRole=new UserRole();
            userRole.setUserId(Integer.parseInt(userId));
            userRole.setRoleId(roleId);
            roleDao.addRole(userRole);
        }

    }


}
