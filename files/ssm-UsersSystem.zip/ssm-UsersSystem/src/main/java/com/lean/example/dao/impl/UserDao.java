package com.lean.example.dao.impl;

import com.lean.example.dao.IUserDao;
import com.lean.example.eo.User;
import com.lean.example.mapper.UserMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class UserDao implements IUserDao {
    @Autowired
    private UserMapper mapper;

    @Override
    public User findUserByUserName(String username) {
        return mapper.findUserByUserName(username);
    }

    @Override
    public List<User> findAll(String username) {
        return mapper.findAll(username);
    }

    @Override
    public void deleteById(int id) {
        mapper.deleteById(id);

    }

    @Override
    public void add(User user) {
        mapper.add(user);

    }

    @Override
    public User selectById(int id) {
        return mapper.selectById(id);
    }

    @Override
    public void update(User user) {
        mapper.update(user);
    }

    @Override
    public int getTotalCount(String username) {
        return mapper.getTotalCount(username);
    }

    @Override
    public void deleteAll(List<Integer> ids) {
        mapper.deleteAll(ids);
    }
}
