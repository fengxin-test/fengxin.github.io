package com.lean.example.eo;

import lombok.Data;

@Data
public class Role {
    private int id;
    private String rolename;
    private String roledesc;
}
