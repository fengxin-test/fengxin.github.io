package com.lean.example.dao;

import com.lean.example.eo.Role;
import com.lean.example.eo.UserRole;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface IRoleDao {
    int getTotalCount(String rolename);

    List<Role> findAll(String rolename);

    List<Integer> findRoleIdByUserId(int userId);

    List<Role> findRoleByUserId(int id);


    void addRole(UserRole userRole);
}
